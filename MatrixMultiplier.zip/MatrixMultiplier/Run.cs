namespace MatrixMultiplier;
using System.Diagnostics;
using Labs;

public class Run
{
    public static void Test()
    {
        Matrix matrix1 = new Matrix();
        Matrix matrix2 = new Matrix();
        MatrixMultiplier mm = new MatrixMultiplier();
        int rows1 = Scanner.GenericInput<int>("Введите число строк первой матрицы: ", "Неверно!", Scanner.IsNatural);
        int cols1 = Scanner.GenericInput<int>("Введите число стобцов первой матрицы: ", "Неверно!", Scanner.IsNatural);
        int rows2 = Scanner.GenericInput<int>("Введите число строк второй матрицы: ", "Неверно!", Scanner.IsNatural);
        int cols2 = Scanner.GenericInput<int>("Введите число столбцов второй матрицы: ", "Неверно!", Scanner.IsNatural);
        int? seed1 = Scanner.NullableInput<int>("Введите seed для первой матрицы: ", "Применён стандартный seed...", Scanner.IsNatural);
        int? seed2 = Scanner.NullableInput<int>("Введите seed для второй матрицы: ", "Применён стандартный seed...", Scanner.IsNatural);
        int threads = Scanner.GenericInput<int>("Введите число потоков: ", "Неверно!", Scanner.IsNatural);
        matrix1.GenerateMatrix(rows1, cols1, 0, 10, seed1);
        matrix2.GenerateMatrix(rows2, cols2, 0, 10, seed2);
        // Console.WriteLine($"\nВаша первая матрица:\n{matrix1}\n");
        // Console.WriteLine($"Ваша вторая матрица:\n{matrix2}\n");
        Stopwatch stopwatch = Stopwatch.StartNew();
        Console.WriteLine("Выполняются вычисления...");
        Matrix result = mm.MultiplyMatrix(matrix1, matrix2, threads, MatrixMultiplier.Modes.Rows);
        stopwatch.Stop();
        Console.WriteLine($"Контрольная сумма: {result.Sum()}");
        // Console.WriteLine($"Результат умножения:\n{result}\n");
        Console.WriteLine($"Матрица посчиталась за {stopwatch.ElapsedMilliseconds} милисекунд");
    }

    public static void CollectStats()
    {
        MatrixMultiplier mm = new MatrixMultiplier();
        int[] sizes = { 500, 1000, 1500 };
        int[] threadCounts = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 16, 24, 48, 96 };
        
        // Прогрев
        var small = new Matrix(); small.GenerateMatrix(1000, 1000, 0, 10);
        mm.MultiplyMatrix(small, small, 12, MatrixMultiplier.Modes.Rows, false);

        using var csv = new StreamWriter("/home/brom/RiderProjects/MatrixMultiplier/MatrixMultiplier/results.csv");
        csv.AutoFlush = true;
        csv.WriteLine("size;threads;run;ms;sum");
        
        for (int i = 0; i < sizes.Length; i++)
        {
            var a = new Matrix(); a.GenerateMatrix(sizes[i], sizes[i], 0, 10, i);
            var b = new Matrix(); b.GenerateMatrix(sizes[i], sizes[i], 0, 10, i + 1);

            foreach (int t in threadCounts)
                for (int run = 1; run <= 5; run++)
                {
                    var sw = Stopwatch.StartNew();
                    Matrix result = mm.MultiplyMatrix(a, b, t, MatrixMultiplier.Modes.Rows, false);
                    sw.Stop();
                    csv.WriteLine($"{sizes[i]};{t};{run};{sw.ElapsedMilliseconds};{result.Sum()}");
                }
        }
    }
}