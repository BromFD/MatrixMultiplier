﻿// See https://aka.ms/new-console-template for more information
using System.Diagnostics;
using Labs;

namespace MatrixMultiplier;

class Program
{
    static void Main()
    {
        //Run.CollectStats();
        //Run.Test();
        TriangleMatrix triangle = new TriangleMatrix();
        triangle.GenerateMatrix(10, 0, 10);
        Console.WriteLine(triangle);
        triangle = triangle.Transpose();
        Console.WriteLine(triangle);
        Console.WriteLine(triangle.Sum());
    }
}