namespace MatrixMultiplier;

public class MatrixMultiplier
{       
    private int _elementsCalculated;
    private int _totalElements;
    public enum Modes { Rows, Elements }
    public long Progress
    {
        get {return (long)(Volatile.Read(ref _elementsCalculated) / (double)_totalElements * 100); }
    }
    
    private long Multiply (long[] row, long[] col)
    {
        long sum = 0;
        for (int i = 0;  i < row.Length; i++)
            sum += row[i] * col[i];
        return sum;
    }
    
    // Считает чуть лучше, но не отдаёт статистику
    private Thread[] RangedElementsDistribution(
        int threads,
        Matrix matrix1, 
        Matrix transMatrix2, 
        Matrix result
        )
    {
        int workPerThread = result.Length / threads;
        int leftoverWork = result.Length % threads;
        (int, int)[] rangeDistribution = new (int, int)[threads];
        Thread[] workDistribution = new Thread[threads];
        
        int[] distribution = Enumerable.Range(0, threads)
            .Select(_ => workPerThread).ToArray();
        for (int i = 0; i < leftoverWork; i++) distribution[i] += 1;
    
        int previousDistribution = 0;
        int currentDistribution = 0;
        for (int i = 0; i < threads; i++)
        {
            int localIndex = i;
            currentDistribution += distribution[i];
            rangeDistribution[i] = (previousDistribution, currentDistribution);
            workDistribution[i] = new Thread(() =>
                RangedElementsMultiplication(
                    matrix1, 
                    transMatrix2, 
                    result, 
                    rangeDistribution[localIndex]
                    ));
            previousDistribution = currentDistribution;
        }

        return workDistribution;
    }

    private void RangedElementsMultiplication(
        Matrix matrix1, 
        Matrix transMatrix2, 
        Matrix result, 
        (int, int) range
        )
    {
        for (int i = range.Item1; i < range.Item2; i++)
        {
            int row = i / result.Cols!.Value;
            int col = i % result.Cols!.Value;
            result.Values![row][col] = Multiply(matrix1.Row(row)!, transMatrix2.Row(col)!);
        }
    }
    
    // Версия предложенная в лабораторной работе, распределение по рядам
    private Thread[] RangedRowsDistribution(
        int threads,
        Matrix matrix1,
        Matrix transMatrix2,
        Matrix result
        )
    {
        int rowsPerThread = result.Rows!.Value / threads;
        int leftoverRows = result.Rows!.Value % threads;
        (int, int)[]  rangeDistribution = new (int, int)[threads];
        
        int[] distribution = Enumerable.Range(0, threads)
            .Select(_ => rowsPerThread).ToArray();
        for (int i = 0; i < leftoverRows; i++) distribution[i] += 1;
        
        Thread[] workDistribution = new Thread[threads];
        
        int previousDistribution = 0;
        int currentDistribution = 0;
        for (int i = 0; i < threads; i++)
        {
            int localIndex = i;
            currentDistribution += distribution[i];
            rangeDistribution[i] = (previousDistribution, currentDistribution);
            workDistribution[i] = new Thread(() =>
                RangedRowsMultiplication(
                    matrix1,
                    transMatrix2,
                    result,
                    rangeDistribution[localIndex]
                    )
            );
            previousDistribution = currentDistribution;
        }
        return workDistribution;
    }

    private void RangedRowsMultiplication(
        Matrix matrix1, 
        Matrix transMatrix2, 
        Matrix result, 
        (int, int) range
        )
    {
        for (int i = range.Item1; i < range.Item2; i++)
        {
            long[] row = result.Values![i];
            long[] rowI = matrix1.Row(i)!;
            
            for (int j = 0; j < row.Length; j++)
            {
                row[j] = Multiply(rowI, transMatrix2.Row(j)!);
            }
            Interlocked.Add(ref _elementsCalculated, row.Length);
        }
    }
    
    public void ReportProgress(Thread[] workers)
    {
        while (workers.Any(t => t.IsAlive))
        {
            Console.Write($"\rПрогресс: {Progress}%");
            Thread.Sleep(50);
        }
        foreach (var t in workers) t.Join();
        Console.WriteLine("\rПрогресс: 100%");
    }
    
    public Matrix MultiplyMatrix(
        Matrix matrix1, 
        Matrix matrix2, 
        int threads,
        Modes mode,
        bool showProgress = true
        )
    {
        if (matrix1.Cols != matrix2.Rows) throw new ArgumentException("Не удалось умножить строку на столбец, несовпадение длин");
        
        _elementsCalculated = 0;
        _totalElements = matrix1.Rows * matrix2.Cols ?? 0;
        int pc = Environment.ProcessorCount;
        if (threads > pc)
            Console.WriteLine($"Предупреждение! " +
                              $"Ваш компьютер имеет всего {pc} потоков, это меньше заявленных {threads}. " +
                              $"Указание большего числа потоков не приведёт к более быстрой работе программы.");
        Matrix result = new Matrix(
            Enumerable.Range(0, matrix1.Rows!.Value)
                .Select(_ => Enumerable
                    .Range(0, matrix2.Cols!.Value)
                    .Select(_ => (long)0).ToArray())
                .ToArray());
        Thread[] tasks;
        if (mode == Modes.Elements)
        {
            tasks = RangedElementsDistribution(
                threads, matrix1, matrix2.Transpose(), result);
        }
        else 
        {
            tasks = RangedRowsDistribution(
                threads, matrix1, matrix2.Transpose(), result);
        }
        foreach (var thread in tasks) thread.Start();
        if (showProgress) ReportProgress(tasks);
        else foreach (var thread in tasks) thread.Join();
        return result;
    }
}